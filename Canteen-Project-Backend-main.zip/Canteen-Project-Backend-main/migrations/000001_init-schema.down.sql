drop table schema_migrations;

drop table "user";

drop table role;

drop table client;

drop table client_category;

